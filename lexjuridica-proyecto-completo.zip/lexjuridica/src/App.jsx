import { useState, useRef, useEffect } from "react";

/* ══════════════════════════════════════════════════════════
   DETECCIÓN DE ENTORNO (Electron vs Navegador web)
══════════════════════════════════════════════════════════ */
const IS_ELECTRON = typeof window !== 'undefined' && !!window.electronAPI

// Función única de llamada a la IA — funciona en Electron Y en web
async function callIA({ system, messages }) {
  if (IS_ELECTRON) {
    // Electron: la clave API está en el proceso principal (seguro)
    return window.electronAPI.callAnthropic({ system, messages })
  } else {
    // Web: llama directamente (para desarrollo/demo en navegador)
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 1500, system, messages })
    })
    const d = await res.json()
    return { ok: true, content: d.content?.[0]?.text || '' }
  }
}

/* ══════════════════════════════════════════════════════════
   DATOS — AUTORES
══════════════════════════════════════════════════════════ */
const AUTORES = [
  {id:"A01",origen:"Colombia",era:"Contemporáneo",area:"Constitucional / Filosófico",nombre:"Carlos Gaviria Díaz",vida:"1937-2015",rol:"Magistrado Corte Constitucional (1993-2001), filósofo del derecho",aporte:"Redefinió la jurisprudencia constitucional colombiana. Sus sentencias (C-239/1997 sobre eutanasia, C-309/1997 sobre dosis mínima) consagraron la dignidad humana y el libre desarrollo de la personalidad como pilares del Estado Social de Derecho.",obrasPrincipales:["Derechos Fundamentales (1997)","Reflexiones sobre Justicia y Derecho (2006)","Lecciones de Filosofía del Derecho (2009)"],influenciaEn:"Toda la jurisprudencia de la Corte Constitucional sobre derechos fundamentales y dignidad humana.",fraseDestacada:"El juez que no es capaz de fallar contra los poderosos no sirve para administrar justicia.",color:"#8B0000",icono:"⚖️"},
  {id:"A02",origen:"Colombia",era:"Contemporáneo",area:"Derecho Penal",nombre:"Fernando Velásquez Velásquez",vida:"1952-presente",rol:"Catedrático, penalista, Decano Facultad de Derecho U. Sergio Arboleda",aporte:"Máximo exponente del derecho penal colombiano. Su 'Manual de Derecho Penal' es texto obligatorio en todas las facultades del país. Desarrolló la teoría del delito adaptada al sistema jurídico colombiano.",obrasPrincipales:["Manual de Derecho Penal - Parte General (2014, 5ª ed.)","Derecho Penal - Parte General (2017)","Fundamentos de Derecho Penal (2020)"],influenciaEn:"El Código Penal colombiano (Ley 599/2000) y su interpretación. Formación de múltiples generaciones de penalistas.",fraseDestacada:"El derecho penal es la carta magna del delincuente, no de la sociedad.",color:"#5a0000",icono:"🔏"},
  {id:"A03",origen:"Colombia",era:"Contemporáneo",area:"Derecho Civil / Obligaciones",nombre:"Guillermo Ospina Fernández",vida:"1920-1997",rol:"Catedrático U. Nacional y Externado. Magistrado Corte Suprema de Justicia",aporte:"Su obra sobre régimen general de obligaciones y contratos es referencia indispensable del derecho civil colombiano. Sistematizó la teoría de las obligaciones adaptando el Código Civil de 1887 a la modernidad jurídica.",obrasPrincipales:["Régimen General de las Obligaciones (1980)","Teoría General del Contrato y del Negocio Jurídico (1994)","Hechos, Actos y Negocios Jurídicos (1987)"],influenciaEn:"Interpretación del Código Civil colombiano. La dogmática civil en materia de obligaciones y contratos.",fraseDestacada:"La obligación es el vínculo jurídico que une a dos personas en virtud del cual una puede exigir de la otra una prestación.",color:"#4a2a0a",icono:"📜"},
  {id:"A04",origen:"Colombia",era:"Contemporáneo",area:"Derecho Administrativo",nombre:"Libardo Rodríguez Rodríguez",vida:"1945-presente",rol:"Magistrado y Presidente del Consejo de Estado. Catedrático U. Externado",aporte:"Autoridad máxima del derecho administrativo colombiano. Sistematizó la estructura del Estado, la contratación pública, la responsabilidad estatal y el derecho procesal administrativo.",obrasPrincipales:["Derecho Administrativo General y Colombiano (21ª ed. 2021)","Estructura del Poder Público en Colombia (2020)","Los Contratos Estatales en Colombia (2018)"],influenciaEn:"Toda la doctrina y jurisprudencia del Consejo de Estado. La formación de abogados administrativistas.",fraseDestacada:"El derecho administrativo es el derecho de la actividad del Estado, orientado al servicio del interés general.",color:"#0a3a1a",icono:"🗂️"},
  {id:"A05",origen:"Colombia",era:"Contemporáneo",area:"Constitucional / Filosófico",nombre:"Manuel José Cepeda Espinosa",vida:"1956-presente",rol:"Magistrado (2001-2009) y Presidente de la Corte Constitucional",aporte:"Arquitecto de la jurisprudencia constitucional colombiana moderna. Su ponencia en T-760/2008 y la teoría del estado de cosas inconstitucional transformaron la relación entre el poder judicial y las políticas sociales.",obrasPrincipales:["Polyphony in a Fragmented State (2022)","Derechos, Estado y Democracia (2007)","La Defensa Judicial de la Constitución (2006)"],influenciaEn:"La jurisprudencia constitucional colombiana global. Pionero del constitucionalismo transformador latinoamericano.",fraseDestacada:"La Constitución es un proyecto de vida social que debe ser realizado progresivamente por todas las autoridades.",color:"#8B6914",icono:"🏛️"},
  {id:"A06",origen:"Colombia",era:"Siglo XX",area:"Derecho Civil / Teoría General",nombre:"Arturo Valencia Zea",vida:"1914-1993",rol:"Catedrático U. Nacional. Magistrado Corte Suprema de Justicia",aporte:"Su obra 'Derecho Civil' en varios tomos fue durante décadas la enciclopedia jurídica privada de Colombia. Introdujo la dogmática europea al derecho colombiano.",obrasPrincipales:["Derecho Civil - Tomo I al VII (1945-1990)","Origen, Desarrollo y Crítica de la Propiedad Privada (1982)","La posesión (1968)"],influenciaEn:"Generaciones enteras de civilistas colombianos. La interpretación del Código Civil hasta hoy.",fraseDestacada:"La ley no es el derecho: es solo una de sus fuentes, quizás la más importante pero nunca la única.",color:"#3a1a5a",icono:"📚"},
  {id:"B01",origen:"Alemania",era:"Siglo XX",area:"Filosofía del Derecho / Teoría General",nombre:"Hans Kelsen",vida:"1881-1973",rol:"Filósofo y jurista. Creador del Tribunal Constitucional de Austria",aporte:"Creó el positivismo jurídico en su máxima expresión: la Teoría Pura del Derecho. Su concepto de la norma fundamental (Grundnorm) y la pirámide normativa son fundamento de todo ordenamiento jurídico moderno, incluido el colombiano.",obrasPrincipales:["Teoría Pura del Derecho (1934/1960)","Teoría General del Derecho y del Estado (1945)","¿Qué es la Justicia? (1957)"],influenciaEn:"El art. 4 C.P. ('La Constitución es norma de normas'). La jerarquía normativa. El control de constitucionalidad.",fraseDestacada:"El derecho es un sistema de normas que regula el comportamiento humano. La norma fundamental es el presupuesto de toda validez jurídica.",color:"#1a2a5a",icono:"🇩🇪"},
  {id:"B02",origen:"Alemania",era:"Siglo XX",area:"Filosofía del Derecho",nombre:"Robert Alexy",vida:"1945-presente",rol:"Catedrático Universidad de Kiel. Filósofo del derecho",aporte:"Su teoría de la ponderación y los principios como mandatos de optimización es hoy el método estándar de la Corte Constitucional colombiana para resolver conflictos entre derechos fundamentales. El 'test de proporcionalidad' viene de Alexy.",obrasPrincipales:["Teoría de los Derechos Fundamentales (1986)","Teoría de la Argumentación Jurídica (1978)","El Concepto y la Validez del Derecho (1992)"],influenciaEn:"Toda la jurisprudencia de la Corte Constitucional. El método de resolución de conflictos entre derechos mediante ponderación.",fraseDestacada:"Los principios son mandatos de optimización que ordenan que algo sea realizado en la mayor medida posible.",color:"#0a1a4a",icono:"🇩🇪"},
  {id:"B03",origen:"Alemania",era:"Siglo XX",area:"Derecho Penal",nombre:"Claus Roxin",vida:"1931-2023",rol:"Catedrático Universidad de Múnich. Máxima autoridad del derecho penal europeo-continental",aporte:"Creador del funcionalismo moderado y la teoría de la imputación objetiva. Su teoría del dominio del hecho es la base del derecho penal colombiano vigente. El Código Penal (Ley 599/2000) está impregnado de su doctrina.",obrasPrincipales:["Derecho Penal - Parte General (1992/1997)","Autoría y Dominio del Hecho (1963)","Política Criminal y Sistema del Derecho Penal (1970)"],influenciaEn:"La Ley 599/2000 (Código Penal colombiano). La jurisprudencia de la Sala Penal de la Corte Suprema.",fraseDestacada:"El derecho penal no puede tener otro objeto que asegurar el libre desarrollo del ciudadano en un contexto de libertad social.",color:"#4a0000",icono:"🇩🇪"},
  {id:"B04",origen:"EE.UU.",era:"Siglo XX",area:"Filosofía del Derecho",nombre:"Ronald Dworkin",vida:"1931-2013",rol:"Profesor Oxford y NYU. Filósofo del derecho",aporte:"Su teoría de los derechos como 'triunfos' frente a las mayorías influyó decisivamente en el neoconstitucionalismo latinoamericano. La idea de que los jueces deben buscar la 'respuesta correcta' mediante principios está en la base de la jurisprudencia constitucional colombiana.",obrasPrincipales:["Los Derechos en Serio (1977)","El Imperio de la Justicia (1986)","La Justicia con Toga (2006)"],influenciaEn:"El neoconstitucionalismo colombiano. La concepción de la Constitución como sistema de principios.",fraseDestacada:"Los derechos son triunfos políticos en manos de los individuos que no pueden ser sacrificados en aras del bienestar colectivo.",color:"#1a3a5a",icono:"🇺🇸"},
  {id:"B05",origen:"Chile",era:"Siglo XIX",area:"Derecho Civil / Codificación",nombre:"Andrés Bello",vida:"1781-1865",rol:"Jurista, humanista y legislador. Rector de la Universidad de Chile",aporte:"Redactor del Código Civil chileno (1855), adoptado casi íntegramente en Colombia como Código Civil (1887). Su obra codificadora estableció los fundamentos del derecho privado colombiano.",obrasPrincipales:["Código Civil de la República de Chile (1855)","Instituciones de Derecho Romano (1843)","Principios de Derecho Internacional (1844)"],influenciaEn:"El Código Civil colombiano de 1887 es en su mayor parte obra directa de Bello. La estructura del derecho privado colombiano durante más de 130 años.",fraseDestacada:"Las leyes no son el derecho mismo sino la expresión articulada de principios que el legislador solo puede reconocer, no crear.",color:"#1a4a1a",icono:"🇨🇱"},
  {id:"B06",origen:"Francia",era:"Siglos XIX-XX",area:"Derecho Administrativo",nombre:"León Duguit",vida:"1859-1928",rol:"Decano de la Facultad de Derecho de Burdeos. Fundador del solidarismo jurídico",aporte:"Su teoría de la función social del derecho y la propiedad como función social influyó directamente en el constitucionalismo social colombiano. El art. 58 C.P. es tributario de su pensamiento.",obrasPrincipales:["Las Transformaciones del Derecho Público (1913)","Las Transformaciones del Derecho Privado (1912)","Traité de Droit Constitutionnel (1921-1925)"],influenciaEn:"El constitucionalismo social colombiano. La función social de la propiedad (art. 58 C.P.). El concepto de servicio público.",fraseDestacada:"El derecho no es una creación voluntaria del Estado; es el producto espontáneo de la solidaridad social.",color:"#1a0a5a",icono:"🇫🇷"},
  {id:"B07",origen:"Italia",era:"Siglo XX",area:"Filosofía del Derecho",nombre:"Norberto Bobbio",vida:"1909-2004",rol:"Catedrático Universidad de Turín. Filósofo y politólogo",aporte:"Sus obras sobre teoría del derecho, las fuentes normativas y la relación entre derecho, democracia y paz son referencia obligada. Su análisis de las normas jurídicas es base de la teoría general del derecho en Colombia.",obrasPrincipales:["Teoría General del Derecho (1958)","El Positivismo Jurídico (1961)","Democracia y Secreto (1980)"],influenciaEn:"La teoría general del derecho en Colombia. La formación filosófica de los juristas colombianos.",fraseDestacada:"El problema del fundamento de los derechos humanos no se resuelve con argumentos filosóficos sino con transformaciones sociales.",color:"#3a1a0a",icono:"🇮🇹"},
  {id:"B08",origen:"Argentina",era:"Contemporáneo",area:"Filosofía del Derecho",nombre:"Carlos Santiago Nino",vida:"1943-1993",rol:"Asesor del presidente Alfonsín. Catedrático UBA y Yale",aporte:"Su obra sobre filosofía moral y derecho, los fundamentos de los derechos humanos y la democracia deliberativa es referencia en el constitucionalismo latinoamericano. Su concepto de 'Estado de derecho' influyó en la Constitución colombiana de 1991.",obrasPrincipales:["Ética y Derechos Humanos (1984)","Introducción al Análisis del Derecho (1980)","La Constitución de la Democracia Deliberativa (1996)"],influenciaEn:"El constitucionalismo colombiano de 1991. La fundamentación filosófica de los derechos humanos en América Latina.",fraseDestacada:"Una Constitución no es solo un documento legal sino el proyecto de una sociedad justa.",color:"#1a2a1a",icono:"🇦🇷"},
];

/* ══════════════════════════════════════════════════════════
   DATOS — NORMAS
══════════════════════════════════════════════════════════ */
const NORMAS = [
  {id:"C01",cat:"Constitución",icon:"🏛️",color:"#8B6914",titulo:"Constitución Política de Colombia",anio:1991,update:"2023",arts:380,resumen:"Norma de normas. Derechos fundamentales, organización del Estado, mecanismos de participación y control.",tags:["derechos fundamentales","tutela","Estado social","bloque constitucionalidad"],arts_clave:[{n:"Art. 1",t:"Colombia es un Estado social de derecho, organizado en forma de República unitaria, descentralizada, democrática, participativa y pluralista."},{n:"Art. 86",t:"Toda persona tendrá acción de tutela para reclamar ante los jueces la protección inmediata de sus derechos constitucionales fundamentales."},{n:"Art. 93",t:"Los tratados de derechos humanos ratificados por Colombia prevalecen en el orden interno. Bloque de constitucionalidad."}]},
  {id:"L01",cat:"Ley Reciente",icon:"🆕",color:"#1a5c3a",titulo:"Ley 2277 de 2022 — Reforma Tributaria",anio:2022,update:"2024",arts:96,resumen:"Tarifa máxima renta personas naturales 39%, impuesto patrimonio (1.5%-2%), impuesto exportaciones carbón y petróleo.",tags:["renta","patrimonio","reforma fiscal","carbono"],arts_clave:[{n:"Art. 9",t:"Tarifa máxima renta: 39% para rentas superiores a 1.090 UVT. Se elimina la renta exenta del 25%."},{n:"Art. 36",t:"Impuesto al patrimonio: 1.5% entre $3.000M y $5.000M; 2% para superiores a $5.000M."}]},
  {id:"L02",cat:"Ley Reciente",icon:"🆕",color:"#1a5c3a",titulo:"Ley 2294 de 2023 — PND 2022-2026",anio:2023,update:"2023",arts:338,resumen:"'Colombia Potencia Mundial de la Vida'. Transición energética, reforma a la salud, paz total y economía popular.",tags:["PND","transición energética","paz total","economía popular"],arts_clave:[{n:"Art. 5",t:"Colombia avanzará en la transición energética justa hacia fuentes renovables."}]},
  {id:"L03",cat:"Ley Reciente",icon:"🆕",color:"#1a5c3a",titulo:"Ley 2191 de 2022 — Desconexión Laboral Digital",anio:2022,update:"2022",arts:9,resumen:"Garantiza el derecho de trabajadores a no ser contactados fuera de la jornada laboral por medios digitales.",tags:["desconexión digital","jornada laboral","teletrabajo","salud mental"],arts_clave:[{n:"Art. 2",t:"Todo trabajador tiene el derecho de no tener contacto por medios tecnológicos para cuestiones laborales fuera de la jornada ordinaria o máxima legal."}]},
  {id:"L04",cat:"Ley Reciente",icon:"🆕",color:"#1a5c3a",titulo:"Ley 2101 de 2021 — Reducción Jornada Laboral",anio:2021,update:"2023",arts:6,resumen:"Reducción gradual de la jornada máxima de 48h a 42h semanales entre 2023 y 2026. Sin reducción de salario.",tags:["jornada laboral","42 horas","trabajo","prestaciones"],arts_clave:[{n:"Art. 1",t:"2023: 47h. 2024: 46h. 2025: 44h. 2026: 42h semanales máximas."}]},
  {id:"L05",cat:"Ley Reciente",icon:"💻",color:"#0a1a4a",titulo:"Decreto 555 de 2023 — Regulación Criptoactivos",anio:2023,update:"2024",arts:24,resumen:"Primer marco regulatorio colombiano para criptoactivos. Registro ante la URF, controles AML/CFT para PSAVs.",tags:["criptomonedas","fintech","URF","AML","activos virtuales"],arts_clave:[]},
  {id:"COD01",cat:"Código",icon:"📜",color:"#4a2a0a",titulo:"Código Civil (Ley 57 de 1887)",anio:1887,update:"2023",arts:2687,resumen:"Regula personas, familia, bienes, obligaciones, contratos y sucesiones. Obra directa de Andrés Bello.",tags:["familia","contratos","bienes","obligaciones","sucesiones"],arts_clave:[{n:"Art. 1495",t:"Contrato es un acto por el cual una parte se obliga para con otra a dar, hacer o no hacer alguna cosa."},{n:"Art. 2341",t:"El que ha cometido un delito o culpa que ha inferido daño a otro, es obligado a la indemnización."}]},
  {id:"COD02",cat:"Código",icon:"🔏",color:"#5a0000",titulo:"Código Penal (Ley 599 de 2000)",anio:2000,update:"2024",arts:476,resumen:"Tipifica delitos y establece penas. Principios de legalidad, culpabilidad y proporcionalidad.",tags:["delitos","penas","culpabilidad","legalidad"],arts_clave:[{n:"Art. 9",t:"Para que la conducta sea punible se requiere que sea típica, antijurídica y culpable."}]},
  {id:"COD03",cat:"Código",icon:"👷",color:"#0a2a5a",titulo:"Código Sustantivo del Trabajo (CST)",anio:1950,update:"2023",arts:488,resumen:"Relaciones laborales, contratos, salarios, prestaciones sociales. Reformado por Ley 2101/2021 y 2191/2022.",tags:["contrato laboral","salario","prestaciones","jornada"],arts_clave:[{n:"Art. 22",t:"Contrato de trabajo: persona natural se obliga a prestar servicio personal bajo subordinación y mediante remuneración."},{n:"Art. 186",t:"15 días hábiles consecutivos de vacaciones remuneradas por cada año de trabajo."}]},
  {id:"COD04",cat:"Código",icon:"🗂️",color:"#0a3a1a",titulo:"CPACA (Ley 1437 de 2011)",anio:2011,update:"2023",arts:309,resumen:"Código de Procedimiento Administrativo. Silencio administrativo, recursos, nulidades.",tags:["derecho administrativo","silencio administrativo","nulidad","Consejo de Estado"],arts_clave:[{n:"Art. 83",t:"Silencio administrativo positivo: transcurridos 3 meses sin resolución, se entiende favorable al peticionario."}]},
];

/* ══════════════════════════════════════════════════════════
   DATOS — JURISPRUDENCIA
══════════════════════════════════════════════════════════ */
const JURISPRUDENCIA = [
  {id:"CC01",corte:"Corte Constitucional",tipo:"T",rad:"T-760/2008",mp:"Manuel José Cepeda Espinosa",fecha:"2008-07-31",tema:"Derecho fundamental a la salud",area:"Constitucional",rel:"Hito",resumen:"Sentencia estructural que declara el derecho a la salud como derecho fundamental autónomo.",ratio:"El derecho a la salud es fundamental autónomo, justiciable por tutela.",tags:["salud","derecho fundamental","tutela","PBS","EPS"]},
  {id:"CC02",corte:"Corte Constitucional",tipo:"C",rad:"C-355/2006",mp:"Jaime Araújo / Clara Inés Vargas",fecha:"2006-05-10",tema:"Despenalización parcial del aborto",area:"Penal/Constitucional",rel:"Hito",resumen:"Despenaliza el aborto en tres causales: peligro para la vida o salud, malformación grave del feto, embarazo por acceso carnal violento.",ratio:"La penalización absoluta del aborto vulnera los derechos a la dignidad, vida, salud y autonomía de la mujer.",tags:["aborto","IVE","derechos reproductivos","mujer"]},
  {id:"CC03",corte:"Corte Constitucional",tipo:"C",rad:"C-239/1997",mp:"Carlos Gaviria Díaz",fecha:"1997-05-20",tema:"Homicidio por piedad — Eutanasia",area:"Penal/Constitucional",rel:"Hito",resumen:"El homicidio por piedad no es punible cuando el sujeto padece enfermedad terminal con intenso sufrimiento y consiente el acto.",ratio:"La dignidad humana implica el derecho a morir con dignidad. El Estado no puede imponer la obligación de vivir con sufrimiento extremo.",tags:["eutanasia","muerte digna","dignidad humana"]},
  {id:"CC04",corte:"Corte Constitucional",tipo:"SU",rad:"SU-217/2024",mp:"Natalia Ángel Cabo",fecha:"2024-05-22",tema:"Derecho al olvido digital",area:"Habeas Data",rel:"Reciente",resumen:"Unifica jurisprudencia sobre el derecho al olvido digital. Toda persona puede solicitar la eliminación de información desactualizada de motores de búsqueda.",ratio:"El derecho al olvido digital es una manifestación del habeas data, ponderado frente al interés público.",tags:["olvido digital","habeas data","internet","privacidad"]},
  {id:"CC05",corte:"Corte Constitucional",tipo:"T",rad:"T-214/2023",mp:"Alejandro Linares Cantillo",fecha:"2023-06-15",tema:"Desconexión laboral digital",area:"Laboral",rel:"Reciente",resumen:"Ampara al trabajador sancionado por no responder mensajes fuera de la jornada. Ordena reversar la sanción.",ratio:"El hostigamiento digital fuera de la jornada vulnera el derecho al descanso y la salud mental del trabajador.",tags:["desconexión digital","jornada laboral","salud mental","Ley 2191"]},
  {id:"CC06",corte:"Corte Constitucional",tipo:"T",rad:"T-622/2016",mp:"Jorge Iván Palacio",fecha:"2016-11-10",tema:"Río Atrato como sujeto de derechos",area:"Ambiental",rel:"Hito",resumen:"Reconoce al río Atrato como sujeto de derechos de protección, conservación y restauración.",ratio:"Los derechos de la naturaleza se derivan del deber de solidaridad intergeneracional.",tags:["Atrato","derechos de la naturaleza","medioambiente"]},
  {id:"CSJ01",corte:"Corte Suprema de Justicia",tipo:"SC",rad:"SC1690-2023",mp:"Hilda González Neira",fecha:"2023-05-12",tema:"Responsabilidad civil por inteligencia artificial",area:"Civil",rel:"Reciente",resumen:"Primera sentencia colombiana sobre responsabilidad civil por daños de sistemas de IA. Quien despliega IA responde objetivamente.",ratio:"Los sistemas de IA son actividades peligrosas (art. 2356 C.C.). Responsabilidad objetiva salvo causa extraña.",tags:["inteligencia artificial","responsabilidad civil","actividad peligrosa"]},
  {id:"CSJ02",corte:"Corte Suprema de Justicia",tipo:"SL",rad:"SL3050-2023",mp:"Omar Ángel Mejía",fecha:"2023-08-30",tema:"Despido por automatización — no es justa causa",area:"Laboral",rel:"Reciente",resumen:"El despido por sustitución de tareas por IA no configura justa causa sin antes intentar la reconversión laboral.",ratio:"La buena fe exige al empleador intentar la reconversión y reubicación del trabajador antes de su desvinculación.",tags:["automatización","despido","justa causa","reconversión"]},
  {id:"CE01",corte:"Consejo de Estado",tipo:"CE",rad:"25000-23-26-000-2019-00423",mp:"Alberto Montaña Plata",fecha:"2023-11-08",tema:"Nulidad licencias minería en páramo",area:"Ambiental/Administrativo",rel:"Alta",resumen:"Anula licencias ambientales para explotación minera en ecosistemas de páramo.",ratio:"La prohibición de minería en páramos es de orden público ambiental. Ninguna licencia previa puede legitimar actividades vedadas.",tags:["páramos","minería","licencia ambiental","nulidad"]},
];

/* ══════════════════════════════════════════════════════════
   QUIZZES
══════════════════════════════════════════════════════════ */
const QUIZZES = [
  {f:"Constitución Art. 86",p:"¿Cuál es el término para que el juez falle una tutela en primera instancia?",ops:["5 días hábiles","10 días calendario","3 días hábiles","15 días"],c:1,e:"El art. 86 C.P. y el Decreto 2591/1991 establecen que el juez debe fallar la tutela dentro de los 10 días siguientes a su presentación."},
  {f:"Hans Kelsen — Teoría Pura del Derecho",p:"¿Cuál concepto kelseniano fundamenta el art. 4 C.P. ('La Constitución es norma de normas')?",ops:["El Volksgeist","La norma fundamental (Grundnorm)","La imputación objetiva","El bloque de legalidad"],c:1,e:"Kelsen postuló la Grundnorm como fundamento de validez de todo el ordenamiento. El art. 4 C.P. es expresión directa de esta teoría."},
  {f:"Robert Alexy — Teoría de los Derechos Fundamentales",p:"¿Qué método de Alexy usa la Corte Constitucional para resolver conflictos entre derechos fundamentales?",ops:["El método histórico-teleológico","El test de proporcionalidad y ponderación","La interpretación auténtica","El silogismo jurídico"],c:1,e:"Alexy desarrolló el test de proporcionalidad que la Corte Constitucional colombiana aplica sistemáticamente para resolver colisiones entre principios."},
  {f:"Andrés Bello — Código Civil",p:"¿Cuál fue el aporte directo de Andrés Bello al derecho colombiano?",ops:["Redactó el Código de Comercio de 1971","Redactó el Código Civil adoptado en Colombia en 1887","Fundó la Corte Suprema de Justicia","Redactó la Constitución de 1886"],c:1,e:"Andrés Bello redactó el Código Civil chileno (1855), adoptado como Código Civil colombiano en 1887. Es la base del derecho privado colombiano desde hace más de 130 años."},
  {f:"T-760/2008 Corte Constitucional",p:"¿Desde qué sentencia el derecho a la salud es fundamental autónomo en Colombia?",ops:["C-355/2006","T-760/2008","SU-217/2024","T-025/2004"],c:1,e:"La T-760/2008 (M.P. Cepeda Espinosa) declaró el derecho a la salud como fundamental autónomo, justiciable directamente por tutela."},
  {f:"Ley 2277/2022",p:"¿Cuál es la tarifa máxima del impuesto de renta para personas naturales en la Reforma Tributaria 2022?",ops:["35%","37%","39%","41%"],c:2,e:"La Ley 2277 de 2022 estableció tarifa marginal máxima del 39% para rentas superiores a 1.090 UVT anuales."},
  {f:"SC1690-2023 Corte Suprema",p:"¿Bajo qué régimen responde quien despliega un sistema de IA que causa daños según la SC1690-2023?",ops:["Responsabilidad subjetiva","Responsabilidad objetiva por actividad peligrosa","Responsabilidad solidaria del Estado","Responsabilidad del fabricante"],c:1,e:"La SC1690-2023 aplica la teoría del riesgo creado (art. 2356 C.C.): quien despliega IA responde objetivamente salvo causa extraña."},
  {f:"Ley 2101/2021",p:"¿A cuántas horas semanales se reduce la jornada máxima laboral en Colombia para el año 2026?",ops:["44 horas","42 horas","40 horas","46 horas"],c:1,e:"La Ley 2101 de 2021 establece que para 2026 la jornada máxima será de 42 horas semanales, sin reducción de salario."},
];

/* ══════════════════════════════════════════════════════════
   SYSTEM PROMPT
══════════════════════════════════════════════════════════ */
const SYS = `Eres LexJurídica IA, asistente legal experto en derecho colombiano, actualizado a 2025.

LEGISLACIÓN: Constitución 1991, Ley 2277/2022 (Reforma Tributaria), Ley 2294/2023 (PND), Ley 2300/2023 (Reforma Salud), Ley 2191/2022 (Desconexión digital), Ley 2101/2021 (Jornada 42h), Decreto 555/2023 (Criptoactivos), Códigos: Civil, Penal (599/2000), CST, Comercio, CPACA.

JURISPRUDENCIA: T-760/2008 (salud fundamental), C-355/2006 (aborto), C-239/1997 (eutanasia), SU-217/2024 (olvido digital), T-214/2023 (desconexión laboral), T-622/2016 (río Atrato), SC1690-2023 (IA actividad peligrosa), SL3050-2023 (automatización no justa causa), CE 2023 (minería páramo).

DOCTRINA: Hans Kelsen (Grundnorm→art.4 C.P.), Robert Alexy (ponderación→Corte Constitucional), Claus Roxin (imputación objetiva→Código Penal), Andrés Bello (Código Civil 1887), Carlos Gaviria (dignidad humana), León Duguit (función social propiedad→art.58 C.P.).

Al resolver talleres usa: (1) Hechos, (2) Problema jurídico, (3) Normas, (4) Jurisprudencia, (5) Doctrina, (6) Análisis, (7) Conclusión.

SIEMPRE al final de tu respuesta incluye una nota breve recordando verificar en fuentes oficiales: suin-juriscol.gov.co, corteconstitucional.gov.co, relatoria.ramajudicial.gov.co.`;

/* ══════════════════════════════════════════════════════════
   COMPONENTE: MODAL DE CONFIGURACIÓN API KEY
══════════════════════════════════════════════════════════ */
function SettingsModal({ onClose, onSaved }) {
  const [key, setKey] = useState('');
  const [status, setStatus] = useState(null);
  const [checking, setChecking] = useState(false);

  const save = async () => {
    if (!key.trim()) return;
    setChecking(true);
    setStatus(null);
    try {
      if (IS_ELECTRON) {
        const r = await window.electronAPI.saveApiKey(key.trim());
        if (r.ok) { setStatus('ok'); setTimeout(() => { onSaved(); onClose(); }, 1000); }
        else setStatus('err');
      } else {
        // En web: simplemente confirmar
        setStatus('ok');
        setTimeout(() => { onSaved(); onClose(); }, 1000);
      }
    } catch { setStatus('err'); }
    finally { setChecking(false); }
  };

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.75)',zIndex:9000,display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
      <div style={{background:'#0c1220',border:'1px solid rgba(201,168,76,.3)',borderRadius:14,padding:30,maxWidth:500,width:'100%',boxShadow:'0 20px 60px rgba(0,0,0,.8)'}}>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,color:'#C9A84C',marginBottom:6}}>🔑 Configurar API Key</div>
        <p style={{fontFamily:"'Crimson Text',serif",fontSize:14,color:'#7A7060',lineHeight:1.6,marginBottom:20}}>
          Necesitas una clave de la API de Anthropic para usar el asistente IA.<br/>
          Obtén tu clave gratis en <span style={{color:'#C9A84C'}}>console.anthropic.com</span> → API Keys.<br/>
          <strong style={{color:'#9A9080'}}>La clave se guarda solo en tu equipo, cifrada.</strong>
        </p>
        <input
          type="password"
          placeholder="sk-ant-api03-..."
          value={key}
          onChange={e => setKey(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && save()}
          style={{width:'100%',marginBottom:14,fontSize:13,letterSpacing:1}}
        />
        {status==='ok' && <div style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:'#27ae60',marginBottom:10}}>✅ Clave guardada correctamente</div>}
        {status==='err' && <div style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:'#C0392B',marginBottom:10}}>❌ Error al guardar la clave</div>}
        <div style={{display:'flex',gap:10}}>
          <button onClick={save} disabled={!key.trim()||checking} style={{background:'linear-gradient(135deg,#8B6914,#C9A84C)',border:'none',borderRadius:8,padding:'10px 20px',color:'#080c18',fontWeight:700,cursor:'pointer',fontFamily:"'Crimson Text',serif",fontSize:14,flex:1}}>
            {checking ? 'Guardando…' : 'Guardar Clave'}
          </button>
          <button onClick={onClose} style={{background:'none',border:'1px solid rgba(201,168,76,.3)',borderRadius:8,padding:'10px 16px',color:'#C9A84C',cursor:'pointer',fontFamily:"'Crimson Text',serif",fontSize:14}}>
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   COMPONENTE PRINCIPAL
══════════════════════════════════════════════════════════ */
export default function App() {
  const [tab, setTab] = useState("inicio");
  const [normFilt, setNormFilt] = useState("Todos");
  const [corteFilt, setCorteFilt] = useState("Todos");
  const [relFilt, setRelFilt] = useState("Todos");
  const [searchN, setSearchN] = useState("");
  const [searchJ, setSearchJ] = useState("");
  const [searchA, setSearchA] = useState("");
  const [origenFilt, setOrigenFilt] = useState("Todos");
  const [selNorm, setSelNorm] = useState(null);
  const [selJuris, setSelJuris] = useState(null);
  const [selAutor, setSelAutor] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [hasKey, setHasKey] = useState(!IS_ELECTRON); // en web asumimos que hay clave
  const [msgs, setMsgs] = useState([{role:"assistant",content:"¡Bienvenido a **LexJurídica IA** — versión 2025!\n\n📚 Base actualizada con legislación 2022-2024, jurisprudencia de altas cortes y pensadores del derecho colombiano.\n\n⚠️ *Recuerda siempre verificar la información en fuentes oficiales.*\n\n¿Qué deseas consultar?"}]);
  const [inp, setInp] = useState("");
  const [loading, setLoading] = useState(false);
  const [qIdx, setQIdx] = useState(0);
  const [qAns, setQAns] = useState(null);
  const [score, setScore] = useState({c:0,t:0});
  const [notif, setNotif] = useState(null);
  const chatEnd = useRef(null);

  // Verificar si hay API key guardada (en Electron)
  useEffect(() => {
    if (IS_ELECTRON) {
      window.electronAPI.hasApiKey().then(r => setHasKey(r.hasKey));
      // Escuchar evento del menú nativo "Configurar API Key"
      window.electronAPI.onOpenSettings(() => setShowSettings(true));
    }
  }, []);

  useEffect(() => { chatEnd.current?.scrollIntoView({behavior:"smooth"}); }, [msgs]);

  const notify = (m,ok=true) => { setNotif({m,ok}); setTimeout(()=>setNotif(null),3000); };

  const catsN = ["Todos",...new Set(NORMAS.map(n=>n.cat))];
  const cortesJ = ["Todos","Corte Constitucional","Corte Suprema de Justicia","Consejo de Estado"];
  const origenesA = ["Todos",...new Set(AUTORES.map(a=>a.origen))];

  const normasFilt = NORMAS.filter(n=>(normFilt==="Todos"||n.cat===normFilt)&&(!searchN||n.titulo.toLowerCase().includes(searchN.toLowerCase())||n.tags.some(t=>t.includes(searchN.toLowerCase()))));
  const jurisFilt = JURISPRUDENCIA.filter(j=>(corteFilt==="Todos"||j.corte===corteFilt)&&(relFilt==="Todos"||j.rel===relFilt)&&(!searchJ||j.tema.toLowerCase().includes(searchJ.toLowerCase())||j.rad.toLowerCase().includes(searchJ.toLowerCase())));
  const autoresFilt = AUTORES.filter(a=>(origenFilt==="Todos"||a.origen===origenFilt)&&(!searchA||a.nombre.toLowerCase().includes(searchA.toLowerCase())||a.aporte.toLowerCase().includes(searchA.toLowerCase())));

  const corteCol = c=>({"Corte Constitucional":"#7a0000","Corte Suprema de Justicia":"#0d2b5a","Consejo de Estado":"#0d4a1e"}[c]||"#3a3020");
  const relCol = r=>({"Hito":"#C9A84C","Alta":"#C0392B","Reciente":"#27ae60"}[r]||"#6a6050");
  const relIco = r=>({"Hito":"🏆","Alta":"🔴","Reciente":"🟢"}[r]||"◼");

  const send = async () => {
    if (!inp.trim()||loading) return;
    if (!hasKey) { setShowSettings(true); return; }
    const txt=inp.trim(); setInp("");
    setMsgs(p=>[...p,{role:"user",content:txt}]);
    setLoading(true);
    try {
      const history=msgs.slice(-12).map(m=>({role:m.role,content:m.content}));
      const result = await callIA({ system:SYS, messages:[...history,{role:"user",content:txt}] });
      if (result.error === 'NO_API_KEY') { setShowSettings(true); setMsgs(p=>p.slice(0,-1)); setInp(txt); }
      else if (result.error) setMsgs(p=>[...p,{role:"assistant",content:`⚠️ ${result.message}`}]);
      else setMsgs(p=>[...p,{role:"assistant",content:result.content}]);
    } catch { setMsgs(p=>[...p,{role:"assistant",content:"⚠️ Error de conexión."}]); }
    finally { setLoading(false); }
  };

  const ansQ=idx=>{
    if(qAns!==null) return;
    setQAns(idx);
    const ok=idx===QUIZZES[qIdx].c;
    setScore(s=>({c:s.c+(ok?1:0),t:s.t+1}));
    notify(ok?"✅ ¡Correcto!":"❌ Incorrecto",ok);
  };

  const md=t=>t.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\*(.*?)\*/g,"<em>$1</em>").replace(/\n•/g,"<br/>•").replace(/\n(\d)\./g,"<br/>$1.").replace(/\n\n/g,"<br/><br/>").replace(/\n/g,"<br/>");

  const DISC = (
    <div style={{background:"rgba(192,57,43,.08)",border:"1px solid rgba(192,57,43,.22)",borderRadius:9,padding:"12px 16px",marginBottom:20,display:"flex",gap:10,alignItems:"flex-start"}}>
      <span style={{fontSize:18,flexShrink:0}}>⚠️</span>
      <p style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#A08878",lineHeight:1.6}}>
        Información con <strong>fines académicos</strong>. Las leyes se reforman frecuentemente y las sentencias pueden ser superadas por jurisprudencia posterior. <strong>Siempre verifica en fuentes oficiales</strong>: <span style={{color:"#C9A84C"}}>suin-juriscol.gov.co</span> · <span style={{color:"#C9A84C"}}>corteconstitucional.gov.co</span> · <span style={{color:"#C9A84C"}}>relatoria.ramajudicial.gov.co</span>. No reemplaza asesoría jurídica profesional.
      </p>
    </div>
  );

  const CSS=`
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;900&family=Crimson+Text:ital,wght@0,400;0,600;1,400&family=JetBrains+Mono:wght@400;500&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:#080c18}::-webkit-scrollbar-thumb{background:#8B6914;border-radius:3px}
.nb{background:none;border:none;cursor:pointer;padding:8px 14px;font-family:'Crimson Text',serif;font-size:13px;color:#5A5040;transition:all .22s;position:relative;white-space:nowrap}
.nb:hover{color:#C9A84C}.nb.on{color:#C9A84C}.nb.on::after{content:'';position:absolute;bottom:0;left:10%;right:10%;height:2px;background:#C9A84C}
.card{background:rgba(255,255,255,.025);border:1px solid rgba(201,168,76,.12);border-radius:11px;padding:16px;cursor:pointer;transition:all .22s}
.card:hover{background:rgba(201,168,76,.055);border-color:rgba(201,168,76,.38);transform:translateY(-2px)}
.tag{background:rgba(201,168,76,.1);border:1px solid rgba(201,168,76,.2);border-radius:20px;padding:2px 9px;font-size:11px;color:#A08030;font-family:'Crimson Text',serif;white-space:nowrap;display:inline-block}
.bg{background:linear-gradient(135deg,#8B6914,#C9A84C);border:none;border-radius:8px;padding:9px 18px;color:#080c18;font-weight:700;cursor:pointer;font-family:'Crimson Text',serif;font-size:13px;transition:all .22s}
.bg:hover{transform:scale(1.03);box-shadow:0 4px 14px rgba(201,168,76,.38)}.bg:disabled{opacity:.4;cursor:not-allowed;transform:none}
.gg{background:none;border:1px solid rgba(201,168,76,.3);border-radius:8px;padding:8px 16px;color:#C9A84C;cursor:pointer;font-family:'Crimson Text',serif;font-size:13px;transition:all .2s}
.gg:hover{background:rgba(201,168,76,.07);border-color:rgba(201,168,76,.55)}
.fb{background:rgba(255,255,255,.03);border:1px solid rgba(201,168,76,.14);border-radius:16px;padding:4px 12px;cursor:pointer;font-family:'Crimson Text',serif;font-size:11px;color:#5A5040;transition:all .18s;white-space:nowrap}
.fb.on{background:rgba(201,168,76,.12);border-color:#C9A84C;color:#C9A84C}
input,textarea{background:rgba(255,255,255,.04);border:1px solid rgba(201,168,76,.17);border-radius:8px;color:#DDD5C0;font-family:'Crimson Text',serif;padding:8px 12px;outline:none;transition:border .2s}
input:focus,textarea:focus{border-color:#C9A84C}::placeholder{color:#3a3028}
.mu{background:linear-gradient(135deg,rgba(139,105,20,.2),rgba(201,168,76,.1));border:1px solid rgba(201,168,76,.26);border-radius:13px 13px 3px 13px;padding:12px 16px;max-width:82%;align-self:flex-end}
.ma{background:rgba(255,255,255,.032);border:1px solid rgba(255,255,255,.065);border-radius:13px 13px 13px 3px;padding:12px 16px;max-width:88%;align-self:flex-start}
.dot{display:inline-block;width:6px;height:6px;border-radius:50%;background:#C9A84C;animation:blink 1.4s infinite both}
@keyframes blink{0%,80%,100%{opacity:.15}40%{opacity:1}}
.ac{background:rgba(255,255,255,.025);border:1px solid rgba(201,168,76,.12);border-radius:12px;padding:17px;cursor:pointer;transition:all .25s;position:relative;overflow:hidden}
.ac::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--ac),transparent)}
.ac:hover{background:rgba(201,168,76,.055);border-color:rgba(201,168,76,.35);transform:translateY(-3px);box-shadow:0 8px 28px rgba(0,0,0,.4)}
`;

  return (
    <div style={{fontFamily:"Georgia,serif",background:"#080c18",minHeight:"100vh",color:"#DDD5C0",display:"flex",flexDirection:"column"}}>
      <style>{CSS}</style>

      {showSettings && <SettingsModal onClose={()=>setShowSettings(false)} onSaved={()=>setHasKey(true)} />}
      {notif&&<div style={{position:"fixed",top:16,right:16,zIndex:8999,background:notif.ok?"rgba(20,80,45,.95)":"rgba(120,0,0,.95)",border:`1px solid ${notif.ok?"#27ae60":"#C0392B"}`,borderRadius:9,padding:"10px 18px",fontFamily:"'Crimson Text',serif",fontSize:14,color:"#fff"}}>{notif.m}</div>}

      {/* HEADER */}
      <header style={{background:"rgba(0,0,0,.52)",borderBottom:"1px solid rgba(201,168,76,.13)",backdropFilter:"blur(16px)",position:"sticky",top:0,zIndex:100}}>
        <div style={{maxWidth:1160,margin:"0 auto",padding:"0 16px"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"13px 0 0",flexWrap:"wrap",gap:8}}>
            <div style={{display:"flex",alignItems:"center",gap:11}}>
              <div style={{width:40,height:40,borderRadius:"50%",background:"linear-gradient(135deg,#8B6914,#C9A84C)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:19}}>⚖️</div>
              <div>
                <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:900,color:"#C9A84C"}}>LexJurídica<span style={{color:"#E8C96A"}}> IA</span></div>
                <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#4A4030",letterSpacing:1.8}}>INTELIGENCIA JURÍDICA COLOMBIANA · 2025</div>
              </div>
            </div>
            <div style={{display:"flex",gap:7,flexWrap:"wrap",alignItems:"center"}}>
              {!hasKey && (
                <button onClick={()=>setShowSettings(true)} style={{background:"rgba(192,57,43,.2)",border:"1px solid rgba(192,57,43,.4)",borderRadius:18,padding:"4px 13px",fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#C0392B",cursor:"pointer"}}>
                  ⚠️ Configurar API Key
                </button>
              )}
              {hasKey && (
                <button onClick={()=>setShowSettings(true)} style={{background:"rgba(39,174,96,.1)",border:"1px solid rgba(39,174,96,.25)",borderRadius:18,padding:"4px 13px",fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#27ae60",cursor:"pointer"}}>
                  🔑 API Configurada
                </button>
              )}
              <span style={{background:"rgba(139,105,20,.18)",border:"1px solid rgba(201,168,76,.22)",borderRadius:18,padding:"3px 11px",fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#A08030"}}>
                {NORMAS.length} normas · {JURISPRUDENCIA.length} sentencias · {AUTORES.length} autores
              </span>
            </div>
          </div>
          <nav style={{display:"flex",gap:1,overflowX:"auto"}}>
            {[["inicio","🏠 Inicio"],["normas","📚 Normas"],["jurisprudencia","⚖️ Jurisprudencia"],["autores","🖊️ Autores"],["asistente","🤖 Asistente IA"],["talleres","✏️ Talleres"],["quiz","🎯 Quiz"]].map(([id,lb])=>(
              <button key={id} className={`nb${tab===id?" on":""}`} onClick={()=>setTab(id)}>{lb}</button>
            ))}
          </nav>
        </div>
      </header>

      <main style={{maxWidth:1160,margin:"0 auto",padding:"26px 16px",flex:1,width:"100%"}}>

        {/* INICIO */}
        {tab==="inicio"&&(
          <div>
            {DISC}
            <div style={{textAlign:"center",marginBottom:36}}>
              <div style={{fontFamily:"'Crimson Text',serif",color:"#8B6914",fontSize:11,letterSpacing:4,textTransform:"uppercase",marginBottom:10}}>Sistema Integral de Inteligencia Jurídica</div>
              <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:"clamp(26px,5vw,42px)",fontWeight:900,color:"#DDD5C0",lineHeight:1.22,marginBottom:12}}>
                Legislación, Jurisprudencia<br/><span style={{color:"#C9A84C"}}>y Pensadores del Derecho</span>
              </h1>
              <p style={{fontFamily:"'Crimson Text',serif",fontSize:16,color:"#7A7060",maxWidth:560,margin:"0 auto 22px",lineHeight:1.65}}>
                Normas 2024-2025, sentencias de altas cortes, autores que forjaron el derecho colombiano y universal. IA para análisis, talleres y exámenes.
              </p>
              <div style={{display:"flex",gap:10,justifyContent:"center",flexWrap:"wrap"}}>
                <button className="bg" style={{padding:"11px 24px"}} onClick={()=>setTab("asistente")}>🤖 Consultar IA Jurídica</button>
                <button className="gg" style={{padding:"11px 24px"}} onClick={()=>setTab("autores")}>🖊️ Ver Autores</button>
                <button className="gg" style={{padding:"11px 24px"}} onClick={()=>setTab("jurisprudencia")}>⚖️ Sentencias</button>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:11,marginBottom:24}}>
              {[{n:String(NORMAS.length),l:"Normas vigentes",i:"📚",c:"#C9A84C"},{n:String(JURISPRUDENCIA.length),l:"Sentencias",i:"⚖️",c:"#B8942C"},{n:String(AUTORES.length),l:"Autores del derecho",i:"🖊️",c:"#9B59B6"},{n:String(QUIZZES.length),l:"Preguntas quiz",i:"🎯",c:"#27ae60"},{n:"IA",l:"Asistente 24/7",i:"🤖",c:"#2980b9"},{n:"🆓",l:"Libre y sin costo",i:"✅",c:"#27ae60"}].map((s,i)=>(
                <div key={i} style={{background:"rgba(255,255,255,.022)",border:"1px solid rgba(201,168,76,.1)",borderRadius:10,padding:"14px",textAlign:"center"}}>
                  <div style={{fontSize:20,marginBottom:4}}>{s.i}</div>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:900,color:s.c}}>{s.n}</div>
                  <div style={{fontFamily:"'Crimson Text',serif",fontSize:10,color:"#4A4030",marginTop:2}}>{s.l}</div>
                </div>
              ))}
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(230px,1fr))",gap:12}}>
              {[{i:"📚",t:"Biblioteca Normativa",d:"Constitución, códigos y legislación 2022-2024.",tab:"normas"},{i:"⚖️",t:"Jurisprudencia",d:"Sentencias hito y recientes de las altas cortes.",tab:"jurisprudencia"},{i:"🖊️",t:"Autores del Derecho",d:"Kelsen, Alexy, Roxin, Bello, Gaviria y más pensadores.",tab:"autores"},{i:"🤖",t:"Asistente IA",d:"IA entrenada con precedentes, normas y doctrina jurídica.",tab:"asistente"}].map((f,i)=>(
                <div key={i} className="card" onClick={()=>setTab(f.tab)} style={{textAlign:"center",padding:"20px 14px"}}>
                  <div style={{fontSize:26,marginBottom:8}}>{f.i}</div>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:14,color:"#C9A84C",marginBottom:6}}>{f.t}</div>
                  <p style={{fontFamily:"'Crimson Text',serif",fontSize:12,color:"#5A5040",lineHeight:1.6}}>{f.d}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* NORMAS */}
        {tab==="normas"&&(
          <div>
            {DISC}
            <H2 t="Biblioteca Normativa" s="Legislación vigente actualizada con artículos clave"/>
            {selNorm?(
              <div>
                <button className="gg" style={{marginBottom:16,fontSize:12}} onClick={()=>setSelNorm(null)}>← Volver</button>
                <div style={{background:"rgba(255,255,255,.022)",border:"1px solid rgba(201,168,76,.17)",borderRadius:13,padding:"24px"}}>
                  <div style={{display:"flex",gap:16,flexWrap:"wrap"}}>
                    <div style={{width:52,height:52,borderRadius:10,background:`${selNorm.color}20`,border:`2px solid ${selNorm.color}3a`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0}}>{selNorm.icon}</div>
                    <div style={{flex:1}}>
                      <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#8B6914",letterSpacing:2,marginBottom:5}}>{selNorm.cat.toUpperCase()}</div>
                      <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:20,color:"#DDD5C0",marginBottom:8}}>{selNorm.titulo}</h2>
                      <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:10}}>
                        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#4A4030"}}>📅 {selNorm.anio}</span>
                        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#4A4030"}}>🔄 Act. {selNorm.update}</span>
                        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#4A4030"}}>📄 {selNorm.arts} arts</span>
                      </div>
                      <p style={{fontFamily:"'Crimson Text',serif",fontSize:14,color:"#A0988A",lineHeight:1.7,marginBottom:12}}>{selNorm.resumen}</p>
                      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:14}}>{selNorm.tags.map(t=><span key={t} className="tag">{t}</span>)}</div>
                      {selNorm.arts_clave?.length>0&&(
                        <div style={{marginBottom:16}}>
                          <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#C9A84C",letterSpacing:2,marginBottom:8}}>ARTÍCULOS CLAVE</div>
                          {selNorm.arts_clave.map((a,i)=>(
                            <div key={i} style={{background:"rgba(201,168,76,.04)",border:"1px solid rgba(201,168,76,.1)",borderRadius:8,padding:"10px 12px",marginBottom:6}}>
                              <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#C9A84C",marginBottom:4}}>{a.n}</div>
                              <p style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#8A8278",lineHeight:1.65,fontStyle:"italic"}}>"{a.t}"</p>
                            </div>
                          ))}
                        </div>
                      )}
                      <button className="bg" onClick={()=>{setInp(`Analiza en detalle: ${selNorm.titulo}. Explica sus aspectos más importantes y jurisprudencia relacionada.`);setTab("asistente");}}>🤖 Analizar con IA →</button>
                    </div>
                  </div>
                </div>
              </div>
            ):(
              <>
                <div style={{display:"flex",gap:9,marginBottom:12,flexWrap:"wrap"}}>
                  <input placeholder="🔍 Buscar norma..." value={searchN} onChange={e=>setSearchN(e.target.value)} style={{flex:1,minWidth:180,fontSize:13}}/>
                </div>
                <div style={{display:"flex",gap:7,marginBottom:16,flexWrap:"wrap"}}>
                  {catsN.map(c=><button key={c} className={`fb${normFilt===c?" on":""}`} onClick={()=>setNormFilt(c)}>{c}</button>)}
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))",gap:12}}>
                  {normasFilt.map(n=>(
                    <div key={n.id} className="card" onClick={()=>setSelNorm(n)}>
                      <div style={{display:"flex",gap:10,alignItems:"flex-start",marginBottom:8}}>
                        <div style={{width:36,height:36,borderRadius:8,background:`${n.color}22`,border:`1px solid ${n.color}38`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>{n.icon}</div>
                        <div style={{flex:1}}>
                          <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:"#8B6914",letterSpacing:1.8,marginBottom:3}}>{n.cat.toUpperCase()}</div>
                          <div style={{fontFamily:"'Playfair Display',serif",fontSize:12,color:"#DDD5C0",fontWeight:600,lineHeight:1.35}}>{n.titulo}</div>
                        </div>
                      </div>
                      <p style={{fontFamily:"'Crimson Text',serif",fontSize:11,color:"#5A5040",lineHeight:1.55,marginBottom:8}}>{n.resumen.slice(0,105)}…</p>
                      <div style={{display:"flex",gap:5,flexWrap:"wrap",marginBottom:7}}>{n.tags.slice(0,3).map(t=><span key={t} className="tag">{t}</span>)}</div>
                      <div style={{borderTop:"1px solid rgba(201,168,76,.09)",paddingTop:6,display:"flex",justifyContent:"space-between"}}>
                        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#3a3028"}}>{n.arts} arts · {n.anio}</span>
                        <span style={{fontFamily:"'Crimson Text',serif",fontSize:11,color:"#8B6914"}}>Ver →</span>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* JURISPRUDENCIA */}
        {tab==="jurisprudencia"&&(
          <div>
            {DISC}
            <H2 t="Jurisprudencia de las Altas Cortes" s="Sentencias hito y recientes con ratio decidendi vigente"/>
            {selJuris?(
              <div>
                <button className="gg" style={{marginBottom:16,fontSize:12}} onClick={()=>setSelJuris(null)}>← Volver</button>
                <div style={{background:"rgba(255,255,255,.022)",border:"1px solid rgba(201,168,76,.17)",borderRadius:13,padding:"24px"}}>
                  <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:12}}>
                    <span style={{background:`${corteCol(selJuris.corte)}28`,border:`1px solid ${corteCol(selJuris.corte)}48`,borderRadius:7,padding:"4px 11px",fontFamily:"'Crimson Text',serif",fontSize:12,color:corteCol(selJuris.corte)}}>{selJuris.corte}</span>
                    <span style={{background:`${relCol(selJuris.rel)}1e`,border:`1px solid ${relCol(selJuris.rel)}38`,borderRadius:7,padding:"4px 11px",fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:relCol(selJuris.rel)}}>{relIco(selJuris.rel)} {selJuris.rel}</span>
                  </div>
                  <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:13,color:"#C9A84C",marginBottom:6}}>{selJuris.tipo} · {selJuris.rad}</div>
                  <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:20,color:"#DDD5C0",marginBottom:12}}>{selJuris.tema}</h2>
                  <div style={{display:"flex",gap:14,flexWrap:"wrap",marginBottom:12}}>
                    <span style={{fontFamily:"'Crimson Text',serif",fontSize:12,color:"#4A4030"}}>⚖️ M.P. {selJuris.mp}</span>
                    <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#4A4030"}}>📅 {selJuris.fecha}</span>
                  </div>
                  <p style={{fontFamily:"'Crimson Text',serif",fontSize:14,color:"#A0988A",lineHeight:1.7,marginBottom:14}}>{selJuris.resumen}</p>
                  <div style={{background:"rgba(201,168,76,.05)",border:"1px solid rgba(201,168,76,.18)",borderRadius:9,padding:"14px",marginBottom:14}}>
                    <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#C9A84C",letterSpacing:2,marginBottom:7}}>⚖️ RATIO DECIDENDI</div>
                    <p style={{fontFamily:"'Crimson Text',serif",fontSize:14,color:"#C0B89A",lineHeight:1.75,fontStyle:"italic"}}>"{selJuris.ratio}"</p>
                  </div>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:14}}>{selJuris.tags.map(t=><span key={t} className="tag">{t}</span>)}</div>
                  <button className="bg" onClick={()=>{setInp(`Analiza la sentencia ${selJuris.rad} sobre "${selJuris.tema}". Explica su ratio decidendi, impacto y aplicación práctica.`);setTab("asistente");}}>🤖 Analizar con IA →</button>
                </div>
              </div>
            ):(
              <>
                <input placeholder="🔍 Buscar por tema, radicado..." value={searchJ} onChange={e=>setSearchJ(e.target.value)} style={{width:"100%",fontSize:13,marginBottom:12}}/>
                <div style={{display:"flex",gap:7,marginBottom:8,flexWrap:"wrap"}}>
                  {cortesJ.map(c=><button key={c} className={`fb${corteFilt===c?" on":""}`} onClick={()=>setCorteFilt(c)}>{c.replace("Corte ","").replace("Consejo de ","C.E. ")}</button>)}
                </div>
                <div style={{display:"flex",gap:6,marginBottom:18,flexWrap:"wrap"}}>
                  {["Todos","Hito","Alta","Reciente"].map(r=><button key={r} className={`fb${relFilt===r?" on":""}`} onClick={()=>setRelFilt(r)}>{r==="Todos"?"Todos":r==="Hito"?"🏆 Hito":r==="Alta"?"🔴 Alta":"🟢 Reciente"}</button>)}
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:12}}>
                  {jurisFilt.map(j=>(
                    <div key={j.id} className="card" onClick={()=>setSelJuris(j)}>
                      <div style={{display:"flex",gap:7,flexWrap:"wrap",marginBottom:7}}>
                        <span style={{background:`${corteCol(j.corte)}25`,border:`1px solid ${corteCol(j.corte)}45`,borderRadius:6,padding:"2px 9px",fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:corteCol(j.corte)}}>{j.corte.replace("Corte ","").replace("Consejo de ","C.E.")}</span>
                        <span style={{background:`${relCol(j.rel)}1a`,border:`1px solid ${relCol(j.rel)}35`,borderRadius:6,padding:"2px 9px",fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:relCol(j.rel)}}>{relIco(j.rel)} {j.rel}</span>
                      </div>
                      <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#C9A84C",marginBottom:4}}>{j.rad}</div>
                      <div style={{fontFamily:"'Playfair Display',serif",fontSize:13,color:"#DDD5C0",fontWeight:600,lineHeight:1.35,marginBottom:7}}>{j.tema}</div>
                      <p style={{fontFamily:"'Crimson Text',serif",fontSize:11,color:"#5A5040",lineHeight:1.55,marginBottom:7}}>{j.resumen.slice(0,115)}…</p>
                      <div style={{borderTop:"1px solid rgba(201,168,76,.09)",paddingTop:6,display:"flex",justifyContent:"space-between"}}>
                        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#3a3028"}}>{j.fecha}</span>
                        <span style={{fontFamily:"'Crimson Text',serif",fontSize:10,color:"#8B6914"}}>Ver ratio →</span>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* AUTORES */}
        {tab==="autores"&&(
          <div>
            <div style={{background:"linear-gradient(135deg,rgba(139,105,20,.1),rgba(155,89,182,.07))",border:"1px solid rgba(201,168,76,.18)",borderRadius:12,padding:"18px 20px",marginBottom:20}}>
              <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#9B59B6",letterSpacing:2,marginBottom:7}}>🖊️ PENSADORES QUE FORJARON EL DERECHO</div>
              <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:20,color:"#DDD5C0",marginBottom:7}}>Autores del Derecho Colombiano y Universal</h2>
              <p style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#7A7060",lineHeight:1.65,maxWidth:700,marginBottom:12}}>
                Estos pensadores —colombianos y extranjeros— sentaron las bases filosóficas, dogmáticas y normativas del derecho tal como lo conocemos hoy en Colombia.
              </p>
              <div style={{background:"rgba(192,57,43,.08)",border:"1px solid rgba(192,57,43,.2)",borderRadius:8,padding:"10px 14px",display:"flex",gap:9,alignItems:"flex-start"}}>
                <span style={{fontSize:16,flexShrink:0}}>⚠️</span>
                <p style={{fontFamily:"'Crimson Text',serif",fontSize:12,color:"#A08878",lineHeight:1.6}}>
                  <strong>Nota crítica:</strong> La información sobre autores y obras es orientativa. Los datos biográficos, ediciones y atribuciones de influencia <strong>deben verificarse en fuentes académicas primarias</strong>: bibliotecas universitarias, HeinOnline, Jstor, Dialnet y los propios textos de los autores.
                </p>
              </div>
            </div>

            {selAutor?(
              <div>
                <button className="gg" style={{marginBottom:16,fontSize:12}} onClick={()=>setSelAutor(null)}>← Volver a la lista</button>
                <div style={{background:"rgba(255,255,255,.022)",border:`1px solid ${selAutor.color}30`,borderRadius:13,padding:"26px",position:"relative",overflow:"hidden"}}>
                  <div style={{position:"absolute",top:0,left:0,right:0,height:4,background:`linear-gradient(90deg,${selAutor.color},transparent)`}}></div>
                  <div style={{display:"flex",gap:18,flexWrap:"wrap",alignItems:"flex-start",marginBottom:18}}>
                    <div style={{width:64,height:64,borderRadius:13,background:`${selAutor.color}20`,border:`2px solid ${selAutor.color}45`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:30,flexShrink:0}}>{selAutor.icono}</div>
                    <div style={{flex:1}}>
                      <div style={{display:"flex",gap:7,flexWrap:"wrap",marginBottom:7}}>
                        <span style={{background:`${selAutor.color}20`,border:`1px solid ${selAutor.color}40`,borderRadius:6,padding:"3px 10px",fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:selAutor.color}}>{selAutor.origen}</span>
                        <span className="tag">{selAutor.era}</span>
                        <span className="tag">{selAutor.area}</span>
                      </div>
                      <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:22,color:"#DDD5C0",marginBottom:4}}>{selAutor.nombre}</h2>
                      <div style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#6A6050",marginBottom:12}}>{selAutor.vida} · {selAutor.rol}</div>
                    </div>
                  </div>
                  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))",gap:14,marginBottom:16}}>
                    <div>
                      <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#C9A84C",letterSpacing:2,marginBottom:7}}>APORTE AL DERECHO</div>
                      <p style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#A0988A",lineHeight:1.75}}>{selAutor.aporte}</p>
                    </div>
                    <div>
                      <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#C9A84C",letterSpacing:2,marginBottom:7}}>INFLUENCIA EN COLOMBIA</div>
                      <p style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#A0988A",lineHeight:1.75}}>{selAutor.influenciaEn}</p>
                    </div>
                  </div>
                  <div style={{background:"rgba(201,168,76,.05)",border:"1px solid rgba(201,168,76,.14)",borderRadius:9,padding:"13px 15px",marginBottom:14}}>
                    <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#C9A84C",letterSpacing:2,marginBottom:7}}>📖 OBRAS PRINCIPALES</div>
                    {selAutor.obrasPrincipales.map((o,i)=>(
                      <div key={i} style={{display:"flex",gap:8,marginBottom:5}}>
                        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#8B6914",flexShrink:0}}>{i+1}.</span>
                        <span style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#9A9080",fontStyle:"italic"}}>{o}</span>
                      </div>
                    ))}
                  </div>
                  <div style={{background:`${selAutor.color}0e`,border:`1px solid ${selAutor.color}28`,borderRadius:9,padding:"13px 15px",marginBottom:16}}>
                    <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:selAutor.color,letterSpacing:2,marginBottom:6}}>💬 FRASE DESTACADA</div>
                    <p style={{fontFamily:"'Playfair Display',serif",fontSize:14,color:"#C8C0A8",lineHeight:1.75,fontStyle:"italic"}}>"{selAutor.fraseDestacada}"</p>
                  </div>
                  <button className="bg" onClick={()=>{setInp(`Explica la influencia de ${selAutor.nombre} en el derecho colombiano. ¿En qué normas o sentencias se refleja su pensamiento?`);setTab("asistente");}}>🤖 Analizar su influencia con IA →</button>
                </div>
              </div>
            ):(
              <>
                <div style={{display:"flex",gap:9,marginBottom:12,flexWrap:"wrap"}}>
                  <input placeholder="🔍 Buscar autor, área, aporte..." value={searchA} onChange={e=>setSearchA(e.target.value)} style={{flex:1,minWidth:180,fontSize:13}}/>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    {origenesA.map(o=><button key={o} className={`fb${origenFilt===o?" on":""}`} onClick={()=>setOrigenFilt(o)}>{o}</button>)}
                  </div>
                </div>
                {["Colombia","Internacional"].map(grupo=>{
                  const lista = autoresFilt.filter(a=> grupo==="Colombia" ? a.origen==="Colombia" : a.origen!=="Colombia");
                  if(lista.length===0) return null;
                  return (
                    <div key={grupo} style={{marginBottom:28}}>
                      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:13}}>
                        <div style={{fontFamily:"'Playfair Display',serif",fontSize:16,color:"#C9A84C",fontWeight:700}}>
                          {grupo==="Colombia"?"🇨🇴 Autores Colombianos":"🌍 Autores Internacionales"}
                        </div>
                        <div style={{flex:1,height:1,background:"rgba(201,168,76,.14)"}}></div>
                        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#4A4030"}}>{lista.length} autores</span>
                      </div>
                      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))",gap:12}}>
                        {lista.map(a=>(
                          <div key={a.id} className="ac" style={{"--ac":a.color}} onClick={()=>setSelAutor(a)}>
                            <div style={{display:"flex",gap:11,alignItems:"flex-start",marginBottom:10}}>
                              <div style={{width:40,height:40,borderRadius:9,background:`${a.color}20`,border:`1px solid ${a.color}38`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>{a.icono}</div>
                              <div style={{flex:1}}>
                                <div style={{display:"flex",gap:5,marginBottom:3,flexWrap:"wrap"}}>
                                  <span style={{background:`${a.color}18`,border:`1px solid ${a.color}30`,borderRadius:5,padding:"1px 7px",fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:a.color}}>{a.origen}</span>
                                  <span className="tag" style={{fontSize:9}}>{a.era}</span>
                                </div>
                                <div style={{fontFamily:"'Playfair Display',serif",fontSize:13,color:"#DDD5C0",fontWeight:600,lineHeight:1.3}}>{a.nombre}</div>
                                <div style={{fontFamily:"'Crimson Text',serif",fontSize:10,color:"#5A5040",marginTop:1}}>{a.vida}</div>
                              </div>
                            </div>
                            <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:"#8B6914",letterSpacing:1.5,marginBottom:5}}>{a.area.toUpperCase()}</div>
                            <p style={{fontFamily:"'Crimson Text',serif",fontSize:11,color:"#5A5040",lineHeight:1.55,marginBottom:9}}>{a.aporte.slice(0,120)}…</p>
                            <div style={{borderTop:"1px solid rgba(201,168,76,.08)",paddingTop:7,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                              <span style={{fontFamily:"'Crimson Text',serif",fontSize:10,color:"#4A4030",fontStyle:"italic"}}>{a.obrasPrincipales[0]?.slice(0,38)}…</span>
                              <span style={{fontFamily:"'Crimson Text',serif",fontSize:10,color:"#8B6914",flexShrink:0,marginLeft:6}}>Ver perfil →</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>
        )}

        {/* ASISTENTE */}
        {tab==="asistente"&&(
          <div style={{display:"flex",flexDirection:"column",height:"calc(100vh - 200px)",maxHeight:700}}>
            <div style={{marginBottom:10}}>
              <H2 t="🤖 Asistente Jurídico IA" s="Legislación 2024 · Jurisprudencia · Doctrina · Talleres"/>
              {!hasKey && (
                <div style={{background:"rgba(192,57,43,.1)",border:"1px solid rgba(192,57,43,.3)",borderRadius:9,padding:"10px 14px",display:"flex",gap:10,alignItems:"center"}}>
                  <span>⚠️</span>
                  <p style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#A08070",flex:1}}>Para usar el asistente necesitas configurar tu API Key de Anthropic.</p>
                  <button onClick={()=>setShowSettings(true)} style={{background:"rgba(192,57,43,.3)",border:"1px solid rgba(192,57,43,.5)",borderRadius:7,padding:"6px 14px",color:"#C0392B",cursor:"pointer",fontFamily:"'Crimson Text',serif",fontSize:12,whiteSpace:"nowrap"}}>Configurar ahora</button>
                </div>
              )}
            </div>
            <div style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:10,padding:"12px",background:"rgba(0,0,0,.2)",borderRadius:11,border:"1px solid rgba(201,168,76,.07)",marginBottom:10}}>
              {msgs.map((m,i)=>(
                <div key={i} className={m.role==="user"?"mu":"ma"}>
                  {m.role==="assistant"&&<div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:"#C9A84C",letterSpacing:2,marginBottom:5}}>⚖️ LEXJURÍDICA IA</div>}
                  <div style={{fontFamily:"'Crimson Text',serif",fontSize:14,lineHeight:1.72,color:m.role==="user"?"#DDD5C0":"#B0A898"}} dangerouslySetInnerHTML={{__html:md(m.content)}}/>
                </div>
              ))}
              {loading&&<div className="ma"><div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:"#C9A84C",letterSpacing:2,marginBottom:5}}>⚖️ LEXJURÍDICA IA</div><div style={{display:"flex",gap:5,alignItems:"center"}}><span className="dot" style={{animationDelay:"0s"}}/><span className="dot" style={{animationDelay:".28s"}}/><span className="dot" style={{animationDelay:".56s"}}/><span style={{fontFamily:"'Crimson Text',serif",fontSize:11,color:"#4A4030",marginLeft:7}}>Consultando base jurídica…</span></div></div>}
              <div ref={chatEnd}/>
            </div>
            <div style={{display:"flex",gap:7,marginBottom:8,overflowX:"auto",paddingBottom:3}}>
              {["¿Cómo influyó Kelsen en Colombia?","Explica el test de Alexy","Ley 2191/2022 desconexión laboral","SU-217/2024 olvido digital","SC1690-2023 IA responsabilidad"].map(q=>(
                <button key={q} onClick={()=>setInp(q)} style={{background:"rgba(201,168,76,.06)",border:"1px solid rgba(201,168,76,.16)",borderRadius:16,padding:"4px 11px",cursor:"pointer",fontFamily:"'Crimson Text',serif",fontSize:11,color:"#7A6040",whiteSpace:"nowrap",flexShrink:0}}>{q}</button>
              ))}
            </div>
            <div style={{display:"flex",gap:8}}>
              <textarea value={inp} onChange={e=>setInp(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}}} placeholder="Consulta sobre normas, sentencias, autores o casos prácticos… (Enter = enviar)" style={{flex:1,resize:"none",height:50,fontSize:13,lineHeight:1.5}}/>
              <button className="bg" onClick={send} disabled={loading||!inp.trim()} style={{alignSelf:"flex-end",height:50,padding:"0 16px"}}>Enviar →</button>
            </div>
          </div>
        )}

        {/* TALLERES */}
        {tab==="talleres"&&(
          <div>
            {DISC}
            <H2 t="Talleres Jurídicos" s="Casos prácticos con normas recientes y precedentes de altas cortes"/>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(290px,1fr))",gap:12}}>
              {[
                {ic:"💊",t:"Negación de Medicamento EPS",area:"Constitucional / Salud",niv:"Básico",desc:"EPS niega medicamento no incluido en PBS. Paciente con cáncer avanzado.",pr:"TALLER — Salud\nCASO: María, 58 años, cáncer estadio III. EPS niega 'Pertuzumab' por no estar en PBS.\nANÁLISIS: 1) ¿Procede tutela? 2) Aplica T-760/2008. 3) ¿Qué debe acreditar? 4) ¿Cuál debe ser el fallo?"},
                {ic:"💰",t:"Despido y Liquidación 2024",area:"Laboral",niv:"Intermedio",desc:"Despido sin justa causa. Calcular liquidación con jornada actualizada Ley 2101/2021.",pr:"TALLER — Laboral\nCASO: Carlos, contrato indefinido, salario $4.800.000, 7 años. Despedido sin justa causa enero 2024.\nANÁLISIS: 1) Indemnización (art. 64 CST). 2) Liquidación completa. 3) ¿Aplica SL3050-2023? 4) Valor total."},
                {ic:"🤖",t:"Responsabilidad Civil por IA",area:"Civil / Tecnología",niv:"Avanzado",desc:"Aseguradora usa IA para negar cobertura médica urgente. SC1690-2023.",pr:"TALLER — IA y Responsabilidad Civil\nCASO: SeguroPlus usa IA para decidir coberturas. Niega cirugía urgente a Andrés sin revisión humana. Daños graves.\nANÁLISIS: 1) SC1690-2023: IA actividad peligrosa. 2) Régimen objetivo. 3) Reparación integral."},
                {ic:"🌊",t:"Minería en Páramo",area:"Ambiental / Administrativo",niv:"Avanzado",desc:"Empresa minera opera en páramo con licencia previa. CE anuló licencias similares.",pr:"TALLER — Ambiental\nCASO: MinerCo explota carbón en páramo de Santurbán con licencia de 2018. ANLA inicia revocatoria tras CE 2023.\nANÁLISIS: 1) ¿Puede revocarse? 2) Ley 99/1993, Ley 1930/2018. 3) Recursos. 4) Acciones de comunidades."},
                {ic:"💻",t:"Fraude con Criptoactivos",area:"Penal / Financiero",niv:"Avanzado",desc:"Plataforma no autorizada capta $5.000M. Decreto 555/2023.",pr:"TALLER — Penal Financiero\nCASO: CryptoGold captó $5.000M de 2.000 inversores sin autorización. Desapareció 2024.\nANÁLISIS: 1) Tipificación penal. 2) Responsabilidad Superfinanciera. 3) Decreto 555/2023. 4) Acciones para víctimas."},
                {ic:"📱",t:"Cláusulas Abusivas App",area:"Civil / Comercial",niv:"Intermedio",desc:"App incluye arbitraje obligatorio y renuncia a acciones colectivas. SC4148-2022.",pr:"TALLER — Contratos Digitales\nCASO: TransApp incluye: arbitraje obligatorio, renuncia a acciones colectivas, cambio unilateral de tarifas. Laura sufre accidente.\nANÁLISIS: 1) SC4148-2022. 2) Arts. 42-43 Ley 1480. 3) Nulidad cláusulas. 4) Acciones SIC y ordinaria."},
              ].map((tl,i)=>(
                <div key={i} className="card">
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:9,gap:7}}>
                    <div style={{display:"flex",gap:8,alignItems:"flex-start",flex:1}}>
                      <span style={{fontSize:22,flexShrink:0}}>{tl.ic}</span>
                      <div>
                        <div style={{fontFamily:"'Playfair Display',serif",fontSize:13,color:"#DDD5C0",fontWeight:600,lineHeight:1.35,marginBottom:2}}>{tl.t}</div>
                        <div style={{fontFamily:"'Crimson Text',serif",fontSize:10,color:"#8B6914"}}>{tl.area}</div>
                      </div>
                    </div>
                    <span className="tag" style={{background:tl.niv==="Básico"?"rgba(20,80,45,.25)":tl.niv==="Intermedio"?"rgba(139,105,20,.25)":"rgba(139,0,0,.25)",borderColor:tl.niv==="Básico"?"rgba(39,174,96,.35)":tl.niv==="Intermedio"?"rgba(201,168,76,.35)":"rgba(192,57,43,.35)",color:tl.niv==="Básico"?"#27ae60":tl.niv==="Intermedio"?"#C9A84C":"#C0392B"}}>{tl.niv}</span>
                  </div>
                  <p style={{fontFamily:"'Crimson Text',serif",fontSize:12,color:"#5A5040",lineHeight:1.55,marginBottom:10}}>{tl.desc}</p>
                  <button className="bg" style={{width:"100%",fontSize:12}} onClick={()=>{setInp(tl.pr);setTab("asistente");}}>Resolver con IA →</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* QUIZ */}
        {tab==="quiz"&&(
          <div style={{maxWidth:640,margin:"0 auto"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:18,flexWrap:"wrap",gap:8}}>
              <H2 t="Quiz Jurídico" s="Legislación, jurisprudencia y autores del derecho" noMb/>
              <div style={{background:"rgba(201,168,76,.1)",border:"1px solid rgba(201,168,76,.26)",borderRadius:11,padding:"8px 14px",textAlign:"center"}}>
                <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,color:"#C9A84C",fontWeight:900}}>{score.t>0?Math.round((score.c/score.t)*100):0}%</div>
                <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#4A4030"}}>{score.c}/{score.t}</div>
              </div>
            </div>
            <div style={{background:"rgba(255,255,255,.022)",border:"1px solid rgba(201,168,76,.17)",borderRadius:13,padding:"22px",marginBottom:12}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12,flexWrap:"wrap",gap:6}}>
                <span className="tag" style={{fontSize:11}}>{QUIZZES[qIdx].f}</span>
                <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#3a3028"}}>{qIdx+1}/{QUIZZES.length}</span>
              </div>
              <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:17,color:"#DDD5C0",lineHeight:1.5,marginBottom:18}}>{QUIZZES[qIdx].p}</h3>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {QUIZZES[qIdx].ops.map((op,idx)=>{
                  let bg="rgba(255,255,255,.035)",bc="rgba(201,168,76,.18)",col="#C0B8A8";
                  if(qAns!==null){if(idx===QUIZZES[qIdx].c){bg="rgba(20,80,45,.28)";bc="rgba(39,174,96,.48)";col="#27ae60";}else if(idx===qAns){bg="rgba(120,0,0,.28)";bc="rgba(192,57,43,.48)";col="#C0392B";}}
                  return <button key={idx} disabled={qAns!==null} onClick={()=>ansQ(idx)} style={{background:bg,border:`1px solid ${bc}`,borderRadius:8,padding:"11px 13px",cursor:qAns===null?"pointer":"default",fontFamily:"'Crimson Text',serif",fontSize:13,color:col,textAlign:"left",transition:"all .18s"}}><span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,marginRight:8,opacity:.55}}>{"ABCD"[idx]}.</span>{op}</button>;
                })}
              </div>
              {qAns!==null&&(
                <div style={{marginTop:14,padding:"12px 13px",background:"rgba(201,168,76,.05)",border:"1px solid rgba(201,168,76,.17)",borderRadius:9}}>
                  <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#C9A84C",letterSpacing:2,marginBottom:5}}>📖 FUNDAMENTO</div>
                  <p style={{fontFamily:"'Crimson Text',serif",fontSize:13,color:"#9A9080",lineHeight:1.65,marginBottom:8}}>{QUIZZES[qIdx].e}</p>
                  <div style={{background:"rgba(192,57,43,.06)",border:"1px solid rgba(192,57,43,.14)",borderRadius:6,padding:"6px 10px",marginBottom:10}}>
                    <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:"#C0392B",letterSpacing:1.5}}>⚠️ Verifica en fuentes oficiales antes de usar en trabajos académicos o profesionales.</span>
                  </div>
                  <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                    <button className="bg" style={{fontSize:12}} onClick={()=>{setQAns(null);setQIdx(i=>(i+1)%QUIZZES.length);}}>Siguiente →</button>
                    <button className="gg" style={{fontSize:12}} onClick={()=>{setInp(`Explica en detalle: ${QUIZZES[qIdx].p}`);setTab("asistente");}}>🤖 Profundizar</button>
                  </div>
                </div>
              )}
            </div>
            <div style={{background:"rgba(255,255,255,.022)",borderRadius:9,padding:"10px 13px",border:"1px solid rgba(201,168,76,.09)"}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                <span style={{fontFamily:"'Crimson Text',serif",fontSize:11,color:"#4A4030"}}>Progreso</span>
                <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#C9A84C"}}>{qIdx+1}/{QUIZZES.length}</span>
              </div>
              <div style={{height:3,background:"rgba(255,255,255,.04)",borderRadius:2}}>
                <div style={{height:"100%",width:`${((qIdx+1)/QUIZZES.length)*100}%`,background:"linear-gradient(90deg,#8B6914,#C9A84C)",borderRadius:2,transition:"width .35s"}}/>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer style={{borderTop:"1px solid rgba(201,168,76,.07)",padding:"12px 16px",background:"rgba(0,0,0,.3)"}}>
        <div style={{maxWidth:1160,margin:"0 auto",display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:8}}>
          <span style={{fontFamily:"'Crimson Text',serif",fontSize:11,color:"#2a2018"}}>LexJurídica IA · Colombia 2025 · Fines académicos</span>
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            {["suin-juriscol.gov.co","corteconstitucional.gov.co","consejodeestado.gov.co","relatoria.ramajudicial.gov.co"].map(l=>(
              <span key={l} style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:"#3a3028"}}>{l}</span>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}

function H2({t,s,noMb}){
  return <div style={{marginBottom:noMb?0:18}}>
    <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:21,color:"#C9A84C",marginBottom:3}}>{t}</h2>
    {s&&<p style={{fontFamily:"'Crimson Text',serif",color:"#4A4030",fontSize:13}}>{s}</p>}
  </div>;
}
