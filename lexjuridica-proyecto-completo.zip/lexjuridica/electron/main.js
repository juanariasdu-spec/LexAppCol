/**
 * LexJurídica IA — Proceso Principal de Electron
 * La clave API se guarda localmente en el equipo del usuario
 * usando electron-store (cifrado, nunca expuesta en el frontend)
 */

const { app, BrowserWindow, ipcMain, shell, dialog, Menu } = require('electron')
const path = require('path')
const Store = require('electron-store')

// ── Configuración persistente cifrada ──────────────────────────────
const store = new Store({
  name: 'lexjuridica-config',
  encryptionKey: 'lexjuridica-local-key-2025', // cifra los datos en disco
  defaults: {
    apiKey: '',
    windowBounds: { width: 1280, height: 850 }
  }
})

const isDev = process.env.NODE_ENV === 'development'
let mainWindow

// ── Crear ventana principal ─────────────────────────────────────────
function createWindow() {
  const { width, height } = store.get('windowBounds')

  mainWindow = new BrowserWindow({
    width,
    height,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#080c18',
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    title: 'LexJurídica IA',
    show: false, // evita flash blanco al cargar
  })

  // Cargar la app
  if (isDev) {
    mainWindow.loadURL('http://localhost:5173')
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'))
  }

  // Mostrar cuando esté lista (sin flash)
  mainWindow.once('ready-to-show', () => {
    mainWindow.show()
  })

  // Guardar tamaño de ventana al cerrar
  mainWindow.on('close', () => {
    const { width, height } = mainWindow.getBounds()
    store.set('windowBounds', { width, height })
  })

  // Abrir links externos en el navegador del sistema
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url)
    return { action: 'deny' }
  })

  // Menú de la aplicación
  buildMenu()
}

// ── Menú nativo ─────────────────────────────────────────────────────
function buildMenu() {
  const template = [
    ...(process.platform === 'darwin' ? [{
      label: 'LexJurídica IA',
      submenu: [
        { label: 'Acerca de LexJurídica IA', role: 'about' },
        { type: 'separator' },
        { label: 'Configurar API Key…', click: () => mainWindow.webContents.send('open-settings') },
        { type: 'separator' },
        { label: 'Salir', role: 'quit' }
      ]
    }] : []),
    {
      label: 'Archivo',
      submenu: [
        { label: 'Configurar API Key…', click: () => mainWindow.webContents.send('open-settings') },
        { type: 'separator' },
        { label: 'Salir', role: process.platform === 'darwin' ? 'close' : 'quit' }
      ]
    },
    {
      label: 'Ver',
      submenu: [
        { label: 'Recargar', role: 'reload' },
        { label: 'Pantalla Completa', role: 'togglefullscreen' },
        ...(isDev ? [{ type: 'separator' }, { label: 'Herramientas Dev', role: 'toggleDevTools' }] : [])
      ]
    },
    {
      label: 'Ayuda',
      submenu: [
        {
          label: 'Fuentes Oficiales — Suin-Juriscol',
          click: () => shell.openExternal('https://www.suin-juriscol.gov.co')
        },
        {
          label: 'Corte Constitucional',
          click: () => shell.openExternal('https://www.corteconstitucional.gov.co')
        },
        {
          label: 'Consejo de Estado',
          click: () => shell.openExternal('https://www.consejodeestado.gov.co')
        },
        { type: 'separator' },
        {
          label: 'Acerca de…',
          click: () => dialog.showMessageBox(mainWindow, {
            type: 'info',
            title: 'LexJurídica IA',
            message: 'LexJurídica IA v1.0.0',
            detail: 'Sistema de Inteligencia Jurídica Colombiana\n\nDesarrollado con fines académicos.\nLas respuestas no reemplazan asesoría jurídica profesional.\n\nSiempre corrobora con fuentes oficiales.',
            buttons: ['OK']
          })
        }
      ]
    }
  ]

  Menu.setApplicationMenu(Menu.buildFromTemplate(template))
}

// ── IPC: Manejo seguro de la API Key ───────────────────────────────
// Guardar la clave API (solo en disco del usuario, cifrada)
ipcMain.handle('save-api-key', async (_, key) => {
  if (!key || typeof key !== 'string') return { ok: false, error: 'Clave inválida' }
  store.set('apiKey', key.trim())
  return { ok: true }
})

// Verificar si hay clave guardada (sin exponerla)
ipcMain.handle('has-api-key', async () => {
  const key = store.get('apiKey', '')
  return { hasKey: key.length > 0 }
})

// Borrar la clave guardada
ipcMain.handle('clear-api-key', async () => {
  store.delete('apiKey')
  return { ok: true }
})

// ── IPC: Llamada a la API de Anthropic (clave nunca va al frontend) ─
ipcMain.handle('call-anthropic', async (_, { system, messages, maxTokens = 1500 }) => {
  const apiKey = store.get('apiKey', '')

  if (!apiKey) {
    return { error: 'NO_API_KEY', message: 'No hay API Key configurada. Ve a Archivo → Configurar API Key.' }
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: maxTokens,
        system,
        messages
      })
    })

    if (!response.ok) {
      const err = await response.json().catch(() => ({}))
      if (response.status === 401) return { error: 'INVALID_KEY', message: 'API Key inválida. Verifica tu clave en console.anthropic.com' }
      if (response.status === 429) return { error: 'RATE_LIMIT', message: 'Límite de peticiones alcanzado. Espera un momento.' }
      return { error: 'API_ERROR', message: err.error?.message || `Error ${response.status}` }
    }

    const data = await response.json()
    return { ok: true, content: data.content?.[0]?.text || '' }

  } catch (err) {
    return { error: 'NETWORK_ERROR', message: 'Sin conexión a internet. Verifica tu red.' }
  }
})

// ── Ciclo de vida de la app ─────────────────────────────────────────
app.whenReady().then(createWindow)

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow()
})
