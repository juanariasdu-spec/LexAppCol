/**
 * preload.js — Puente seguro entre el proceso principal y la interfaz web
 * Expone SOLO las funciones necesarias, nada más.
 */

const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronAPI', {
  // Llamada a la API de Anthropic (la clave nunca llega al frontend)
  callAnthropic: (payload) => ipcRenderer.invoke('call-anthropic', payload),

  // Gestión de la API Key
  saveApiKey:  (key) => ipcRenderer.invoke('save-api-key', key),
  hasApiKey:   ()    => ipcRenderer.invoke('has-api-key'),
  clearApiKey: ()    => ipcRenderer.invoke('clear-api-key'),

  // Escuchar eventos del menú nativo
  onOpenSettings: (callback) => ipcRenderer.on('open-settings', callback),
})
