# LexJurídica IA — Guía Completa de Instalación y Compilación

> Sistema de Inteligencia Jurídica Colombiana  
> Licencia MIT — Uso libre y gratuito

---

## ¿Qué necesitas?

| Herramienta | Versión | Descarga | Costo |
|---|---|---|---|
| Node.js | 18 o superior | nodejs.org | **Gratis** |
| Git | Cualquiera | git-scm.com | **Gratis** |
| GitHub | Cuenta | github.com | **Gratis** |
| Cuenta Anthropic | — | console.anthropic.com | **Gratis** (con créditos iniciales) |

---

## PARTE 1 — Ejecutar en modo desarrollo (en tu PC)

### Paso 1 — Instalar Node.js

1. Ve a **https://nodejs.org**
2. Descarga la versión **LTS** (recomendada)
3. Instala con todas las opciones por defecto
4. Verifica: abre una terminal y escribe:
   ```
   node --version
   npm --version
   ```
   Debes ver algo como: `v20.x.x` y `10.x.x`

### Paso 2 — Descargar el proyecto

Coloca todos los archivos del proyecto en una carpeta llamada `lexjuridica`.  
La estructura debe quedar así:

```
lexjuridica/
├── package.json
├── vite.config.js
├── index.html
├── LICENSE.txt
├── electron/
│   ├── main.js
│   └── preload.js
├── src/
│   ├── main.jsx
│   └── App.jsx
└── .github/
    └── workflows/
        └── build.yml
```

### Paso 3 — Instalar dependencias

Abre una terminal dentro de la carpeta `lexjuridica` y ejecuta:

```bash
npm install
```

Esto descarga todas las librerías necesarias (puede tardar 2-3 minutos).

### Paso 4 — Ejecutar en modo desarrollo

```bash
npm run electron:dev
```

Se abrirá la aplicación como ventana de escritorio.  
Cada cambio que hagas en el código se refleja automáticamente.

---

## PARTE 2 — Obtener la API Key de Anthropic (GRATIS)

1. Ve a **https://console.anthropic.com**
2. Crea una cuenta gratuita
3. Ve a **API Keys** → **Create Key**
4. Copia la clave (empieza con `sk-ant-api03-...`)
5. Al abrir LexJurídica, haz clic en **"Configurar API Key"**  
   y pega la clave. Se guarda cifrada solo en tu equipo.

> **¿Cuánto cuesta?** Anthropic da créditos gratuitos al registrarte.  
> El modelo Claude Sonnet cuesta aproximadamente $0.003 por consulta.  
> Para uso académico normal, los créditos gratuitos duran meses.

---

## PARTE 3 — Compilar el instalador (sin pagar nada)

### Método A: Compilar en tu propia máquina

#### Windows → genera el archivo .exe

1. Abre una terminal en la carpeta del proyecto
2. Ejecuta:
   ```bash
   npm run electron:build:win
   ```
3. El instalador queda en la carpeta `release/`
   - `LexJuridica IA Setup 1.0.0.exe` — instalador completo
   - `LexJuridica IA 1.0.0.exe` — versión portable (sin instalación)

#### Mac → genera el archivo .dmg

1. En Mac, ejecuta:
   ```bash
   npm run electron:build:mac
   ```
2. El instalador queda en `release/`
   - `LexJuridica IA-1.0.0.dmg` — imagen de disco para Mac
   - `LexJuridica IA-1.0.0-mac.zip` — versión comprimida

#### Linux → genera AppImage

```bash
npm run electron:build:linux
```

> **LIMITACIÓN IMPORTANTE:**  
> Solo puedes compilar el instalador del sistema operativo donde estás trabajando.  
> Para compilar para Windows desde Mac (o viceversa) usa el Método B.

---

### Método B: Compilar para TODOS los sistemas usando GitHub (GRATIS)

Este es el método recomendado. GitHub Actions compila automáticamente  
para Windows, Mac y Linux usando sus servidores gratuitos.

#### Paso 1 — Crear repositorio en GitHub

1. Ve a **https://github.com** y crea una cuenta (gratis)
2. Haz clic en **"New repository"**
3. Nómbralo `lexjuridica`
4. Déjalo público (para usar GitHub Actions gratis sin límites)
5. Haz clic en **"Create repository"**

#### Paso 2 — Subir el código

En la terminal, dentro de la carpeta del proyecto:

```bash
# Inicializar Git
git init

# Agregar todos los archivos
git add .

# Primer commit
git commit -m "LexJurídica IA v1.0.0"

# Conectar con GitHub (reemplaza TU_USUARIO con tu nombre de usuario)
git remote add origin https://github.com/TU_USUARIO/lexjuridica.git

# Subir el código
git push -u origin main
```

#### Paso 3 — Crear un "Release" para activar la compilación automática

```bash
# Crear un tag de versión
git tag v1.0.0

# Subir el tag a GitHub (esto activa la compilación automática)
git push --tags
```

#### Paso 4 — Esperar y descargar los instaladores

1. Ve a tu repositorio en GitHub
2. Haz clic en la pestaña **"Actions"**
3. Verás 3 trabajos ejecutándose: Windows, Mac y Linux
4. Espera ~10-15 minutos
5. Cuando terminen, ve a **"Releases"** en tu repositorio
6. Encontrarás los instaladores listos para descargar:
   - `LexJuridica-IA-Setup-1.0.0.exe` (Windows)
   - `LexJuridica-IA-1.0.0.dmg` (Mac)
   - `LexJuridica-IA-1.0.0.AppImage` (Linux)

---

## PARTE 4 — Instalar en Windows (usuarios finales)

### Método normal (.exe instalador)

1. Descarga `LexJuridica IA Setup 1.0.0.exe`
2. Haz doble clic
3. **IMPORTANTE:** Windows mostrará una advertencia:  
   *"Windows protegió su PC"*  
   → Haz clic en **"Más información"** → **"Ejecutar de todas formas"**  
   *(Esta advertencia aparece porque el instalador no tiene firma de código de pago)*
4. Sigue el asistente de instalación
5. Se crea un acceso directo en el Escritorio y el Menú Inicio

### Método portable (sin instalar)

1. Descarga `LexJuridica IA 1.0.0.exe`
2. Ejecútalo directamente sin instalar nada
3. No requiere permisos de administrador

---

## PARTE 5 — Instalar en Mac (usuarios finales)

1. Descarga `LexJuridica IA-1.0.0.dmg`
2. Haz doble clic para montar la imagen
3. Arrastra la app a la carpeta **Aplicaciones**
4. **IMPORTANTE:** La primera vez que la abras, Mac mostrará:  
   *"No se puede abrir porque proviene de un desarrollador no identificado"*  
   
   **Solución:**
   - Ve a **Preferencias del Sistema** → **Seguridad y Privacidad**
   - Haz clic en **"Abrir de todas formas"**
   
   **O usa este comando en Terminal:**
   ```bash
   xattr -cr "/Applications/LexJuridica IA.app"
   ```

---

## PARTE 6 — Actualizar la aplicación

Cuando quieras agregar nuevas leyes, sentencias o funciones:

1. Modifica el código (por ejemplo, agrega normas en `src/App.jsx`)
2. Sube los cambios a GitHub:
   ```bash
   git add .
   git commit -m "Actualizar jurisprudencia 2025"
   git tag v1.1.0
   git push && git push --tags
   ```
3. GitHub compilará automáticamente los nuevos instaladores

---

## Preguntas Frecuentes

**¿Funciona sin internet?**  
El contenido de normas, jurisprudencia y autores funciona sin internet.  
El asistente IA requiere conexión para llamar a la API de Anthropic.

**¿Es segura la API Key?**  
Sí. La clave se guarda cifrada en el disco del usuario usando `electron-store`.  
Nunca se incluye en el código ni se transmite a ningún servidor excepto Anthropic.

**¿Puedo distribuirlo libremente?**  
Sí. La licencia MIT permite uso, modificación y distribución libre,  
incluso comercial, siempre que se mantenga el aviso de copyright.

**¿Cuesta algo usar GitHub Actions?**  
No para repositorios públicos. GitHub da minutos ilimitados de compilación  
gratuita para proyectos de código abierto.

**¿Cuánto pesa el instalador?**  
Entre 80 MB y 150 MB, porque incluye el motor Chromium de Electron.

---

## Recursos Oficiales para Verificar Información Jurídica

| Fuente | URL |
|---|---|
| Suin-Juriscol (leyes vigentes) | https://www.suin-juriscol.gov.co |
| Corte Constitucional | https://www.corteconstitucional.gov.co |
| Corte Suprema de Justicia | https://cortesuprema.gov.co |
| Consejo de Estado | https://www.consejodeestado.gov.co |
| Secretaría del Senado | https://www.secretariasenado.gov.co |

---

*LexJurídica IA — Uso libre bajo licencia MIT — Fines académicos*
